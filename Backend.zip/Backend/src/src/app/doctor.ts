export class Doctor {
    constructor(public did:number,
        public dname:string,
        public emailid:string,
        public address:string,
        public dgender:string,
        public dage:number,
        public specialization:string,
        public phno:number
        ){}
}
