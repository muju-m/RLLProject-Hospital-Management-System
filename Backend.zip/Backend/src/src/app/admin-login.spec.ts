import { AdminLogin } from './admin-login';

describe('AdminLogin', () => {
  it('should create an instance', () => {
    expect(new AdminLogin()).toBeTruthy();
  });
});
