export class Login {
    constructor(public id:number,
        public emailid:string,
        public password:string,
        public role:string ){}
}
