export class Invoice {
    constructor( 
        public id: number,
       public admitdate: string,
       public disease:string,
       public doctorfee: string,
       public medicinecost:string,
       public othercharge:string,
       public patientaddress:string,
       public patientmobile:string,
       public patientname: string,
       public releasedate: string,
       public roomcharge: string,
        
        
        ){

    }
}
